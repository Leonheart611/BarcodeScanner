package dynamia.com.barcodescanner.viewmodel

import androidx.lifecycle.ViewModel

class ReceivingViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
