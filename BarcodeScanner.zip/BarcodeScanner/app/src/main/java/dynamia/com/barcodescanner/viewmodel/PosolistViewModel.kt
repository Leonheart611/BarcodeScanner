package dynamia.com.barcodescanner.viewmodel

import androidx.lifecycle.ViewModel

class PosolistViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
